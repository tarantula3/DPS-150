Case fnirsi dps-150 by ELEliseev on Thingiverse: https://www.thingiverse.com/thing:7091473

Summary:
Supports disabled,perimeters 2-3,bottom/lid 2-3,layer thickness 0.2-0.3,plastic preferred PETG.Loops are connected via wire (welding).The lid has 4 5x2 mm magnets, that are glued in place with super glue.Please note the polarity of the magnets.